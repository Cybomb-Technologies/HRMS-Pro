import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAppContext } from "@/contexts/AppContext";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/components/ui/use-toast";
import {
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  Plus,
  AlertCircle,
  User,
  CalendarDays,
  PauseCircle,
  TrendingDown,
  Users,
  Ban,
  RotateCcw,
  X,
} from "lucide-react";

const LeaveTab = () => {
  const { leaveRequests: leaveApi } = useAppContext();
  const { user } = useAuth();
  const [leaveRequests, setLeaveRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [currentEmployeeId, setCurrentEmployeeId] = useState(null);
  const [leaveBalance, setLeaveBalance] = useState(null);

  // Form state
  const [formData, setFormData] = useState({
    type: "Annual Leave",
    startDate: "",
    endDate: "",
    reason: "",
  });

  // Fetch leave balance from backend
  const fetchLeaveBalance = async (employeeId) => {
    try {
      if (!employeeId) return;

      const response = await fetch(
        `http://localhost:5000/api/leaves/balance/${employeeId}`
      );
      if (response.ok) {
        const balance = await response.json();
        setLeaveBalance(balance);
        console.log("Fetched leave balance:", balance);
      } else {
        console.error("Failed to fetch leave balance");
        // Fallback to default balance
        setLeaveBalance({
          annualLeave: 6,
          sickLeave: 6,
          personalLeave: 6,
          annualLeaveLimit: 6,
          sickLeaveLimit: 6,
          personalLeaveLimit: 6,
        });
      }
    } catch (error) {
      console.error("Error fetching leave balance:", error);
      // Fallback to default balance
      setLeaveBalance({
        annualLeave: 6,
        sickLeave: 6,
        personalLeave: 6,
        annualLeaveLimit: 6,
        sickLeaveLimit: 6,
        personalLeaveLimit: 6,
      });
    }
  };

  // Check if a leave type is available (has remaining days)
  const isLeaveTypeAvailable = (type) => {
    const remainingDays = getRemainingDays(type);
    return remainingDays > 0;
  };

  // Get available leave types for dropdown
  const getAvailableLeaveTypes = () => {
    const allTypes = [
      { value: "Annual Leave", label: "Annual Leave" },
      { value: "Sick Leave", label: "Sick Leave" },
      { value: "Personal Leave", label: "Personal Leave" },
    ];

    return allTypes.map((type) => ({
      ...type,
      available: isLeaveTypeAvailable(type.value),
      remainingDays: getRemainingDays(type.value),
    }));
  };

  // Fetch all employees from Employee collection
  const fetchAllEmployees = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/employees");
      if (response.ok) {
        const employees = await response.json();
        return employees;
      }
      return [];
    } catch (error) {
      console.error("Error fetching employees:", error);
      return [];
    }
  };

  // Get current employee's ID from Employee collection
  const getCurrentEmployeeId = async () => {
    if (!user?.email) return null;

    const employees = await fetchAllEmployees();
    const employee = employees.find((emp) => emp.email === user.email);
    return employee?.employeeId || null;
  };

  // Load leave requests for current employee
  const loadLeaveRequests = async () => {
    try {
      setLoading(true);
      let requests = [];

      const employeeId = await getCurrentEmployeeId();
      if (!employeeId) {
        console.error("Could not find employee ID for user:", user?.email);
        toast({
          title: "Error",
          description: "Could not load employee information",
          variant: "destructive",
        });
        return;
      }

      setCurrentEmployeeId(employeeId);

      // Fetch leave balance first
      await fetchLeaveBalance(employeeId);

      if (leaveApi?.getLeavesByEmployee) {
        requests = await leaveApi.getLeavesByEmployee(employeeId);
      } else {
        // Mock data for testing
        requests = [
          {
            id: "1",
            type: "Annual Leave",
            startDate: new Date().toISOString(),
            endDate: new Date(Date.now() + 86400000).toISOString(),
            reason: "Vacation",
            status: "pending",
            days: 1,
            appliedDate: new Date().toISOString(),
            employeeId: employeeId,
          },
        ];
      }

      console.log("Loaded leave requests:", requests);
      setLeaveRequests(Array.isArray(requests) ? requests : []);
    } catch (error) {
      console.error("Error loading leave requests:", error);
      toast({
        title: "Error",
        description: "Failed to load leave requests",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Get remaining days for current leave type
  const getRemainingDays = (type) => {
    if (!leaveBalance) return 0;

    const balanceMap = {
      "Annual Leave": leaveBalance.annualLeave,
      "Sick Leave": leaveBalance.sickLeave,
      "Personal Leave": leaveBalance.personalLeave,
    };

    return balanceMap[type] || 0;
  };

  // Get limit for current leave type
  const getLeaveLimit = (type) => {
    if (!leaveBalance) return 6;

    const limitMap = {
      "Annual Leave": leaveBalance.annualLeaveLimit || 6,
      "Sick Leave": leaveBalance.sickLeaveLimit || 6,
      "Personal Leave": leaveBalance.personalLeaveLimit || 6,
    };

    return limitMap[type] || 6;
  };

  // Get balance color based on remaining days
  const getBalanceColor = (current, limit) => {
    const percentage = (current / limit) * 100;
    if (percentage <= 25) return "text-red-600";
    if (percentage <= 50) return "text-yellow-600";
    return "text-green-600";
  };

  // Calculate days between dates
  const calculateDays = (startDate, endDate) => {
    if (!startDate || !endDate) return 0;
    const start = new Date(startDate);
    const end = new Date(endDate);
    const timeDiff = end.getTime() - start.getTime();
    return Math.ceil(timeDiff / (1000 * 60 * 60 * 24)) + 1;
  };

  // Load data on component mount
  useEffect(() => {
    if (user) {
      loadLeaveRequests();
    }
  }, [user]);

  const getStatusBadge = (status) => {
    const variants = {
      pending: { bg: "bg-yellow-100 text-yellow-800", icon: Clock },
      approved: { bg: "bg-green-100 text-green-800", icon: CheckCircle },
      rejected: { bg: "bg-red-100 text-red-800", icon: XCircle },
      cancelled: { bg: "bg-gray-100 text-gray-800", icon: XCircle },
    };

    const variant = variants[status] || variants.pending;
    const IconComponent = variant.icon;

    return (
      <Badge className={`${variant.bg} flex items-center gap-1`}>
        <IconComponent className="w-3 h-3" />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const getLeaveTypeIcon = (type) => {
    const icons = {
      "Annual Leave": Calendar,
      "Sick Leave": AlertCircle,
      "Personal Leave": User,
    };
    return icons[type] || CalendarDays;
  };

  const handleCancel = async (leaveId) => {
    try {
      if (leaveApi?.update) {
        await leaveApi.update(leaveId, {
          status: "cancelled",
          actionBy: user?.name || "Employee",
        });
      } else {
        // Mock update for testing
        console.log(`Cancelling leave ${leaveId}`);
      }

      toast({
        title: "Success",
        description: "Leave request cancelled successfully",
      });

      loadLeaveRequests(); // Refresh the list
    } catch (error) {
      console.error("Error canceling leave:", error);
      toast({
        title: "Error",
        description: "Failed to cancel leave request",
        variant: "destructive",
      });
    }
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    // Check if selected leave type is available
    if (!isLeaveTypeAvailable(formData.type)) {
      toast({
        title: "Leave Not Available",
        description: `${formData.type} is not available. You have 0 days remaining.`,
        variant: "destructive",
      });
      return;
    }

    // Validate form data
    if (!formData.startDate || !formData.endDate || !formData.reason.trim()) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    // Validate dates
    const startDate = new Date(formData.startDate);
    const endDate = new Date(formData.endDate);

    if (endDate < startDate) {
      toast({
        title: "Validation Error",
        description: "End date cannot be before start date",
        variant: "destructive",
      });
      return;
    }

    // Check if dates are in the past
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (startDate < today) {
      toast({
        title: "Error",
        description: "Cannot apply for leave in the past",
        variant: "destructive",
      });
      return;
    }

    // Check if there are enough leave days for paid leaves
    const remainingDays = getRemainingDays(formData.type);
    const requestedDays = calculateDays(formData.startDate, formData.endDate);

    if (requestedDays > remainingDays) {
      toast({
        title: "Insufficient Leave Balance",
        description: `You only have ${remainingDays} days remaining for ${formData.type}. You requested ${requestedDays} days.`,
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);

    try {
      // Get employee data from Employee collection
      const employeeId = await getCurrentEmployeeId();
      if (!employeeId) {
        toast({
          title: "Error",
          description: "Could not find your employee information",
          variant: "destructive",
        });
        return;
      }

      const employees = await fetchAllEmployees();
      const employee = employees.find((emp) => emp.employeeId === employeeId);

      if (!employee) {
        toast({
          title: "Error",
          description: "Could not find your employee record",
          variant: "destructive",
        });
        return;
      }

      const days = calculateDays(formData.startDate, formData.endDate);

      const leaveData = {
        type: formData.type,
        startDate: formData.startDate,
        endDate: formData.endDate,
        reason: formData.reason.trim(),
        employee: employee.name,
        employeeId: employeeId,
        employeeEmail: employee.email,
        approver: "HR Manager",
        approverId: "HR001",
        status: "pending",
        days: days,
      };

      console.log("Submitting leave request:", leaveData);

      if (leaveApi?.create) {
        await leaveApi.create(leaveData);
      } else {
        // Mock create for testing
        console.log("Creating leave request with PENDING status:", leaveData);
      }

      toast({
        title: "Success",
        description: "Leave request submitted successfully",
      });

      setShowForm(false);
      setFormData({
        type: "Annual Leave",
        startDate: "",
        endDate: "",
        reason: "",
      });

      loadLeaveRequests(); // Refresh the list
    } catch (error) {
      console.error("Error creating leave request:", error);
      toast({
        title: "Error",
        description:
          error.message || "Failed to submit leave request. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  // Handle leave type change in form
  const handleLeaveTypeChange = (value) => {
    setFormData({ ...formData, type: value });
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
        <p className="text-muted-foreground mt-2">
          Loading your leave information...
        </p>
      </div>
    );
  }

  const availableLeaveTypes = getAvailableLeaveTypes();
  const requestedDays = calculateDays(formData.startDate, formData.endDate);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">My Leave Requests</h2>
          <p className="text-muted-foreground">
            Track and manage your leave applications
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={loadLeaveRequests}
            disabled={loading}
          >
            <RotateCcw
              className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`}
            />
            Refresh
          </Button>
          <Button onClick={() => setShowForm(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Apply for Leave
          </Button>
        </div>
      </div>

      {/* Employee Leave Balance Card */}
      {leaveBalance && (
        <Card className="p-6 bg-blue-50 border-blue-200">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <TrendingDown className="w-5 h-5 text-blue-600" />
            My Leave Balance
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-3 bg-white rounded-lg border">
              <div
                className={`text-2xl font-bold ${getBalanceColor(
                  leaveBalance.annualLeave,
                  leaveBalance.annualLeaveLimit || 6
                )}`}
              >
                {leaveBalance.annualLeave}
              </div>
              <div className="text-sm text-muted-foreground">Annual Leave</div>
              <div className="text-xs text-gray-500">
                / {leaveBalance.annualLeaveLimit || 6} days
              </div>
              {leaveBalance.annualLeave === 0 && (
                <div className="text-xs text-red-500 font-medium mt-1 flex items-center justify-center gap-1">
                  <Ban className="w-3 h-3" />
                  Not Available
                </div>
              )}
            </div>
            <div className="text-center p-3 bg-white rounded-lg border">
              <div
                className={`text-2xl font-bold ${getBalanceColor(
                  leaveBalance.sickLeave,
                  leaveBalance.sickLeaveLimit || 6
                )}`}
              >
                {leaveBalance.sickLeave}
              </div>
              <div className="text-sm text-muted-foreground">Sick Leave</div>
              <div className="text-xs text-gray-500">
                / {leaveBalance.sickLeaveLimit || 6} days
              </div>
              {leaveBalance.sickLeave === 0 && (
                <div className="text-xs text-red-500 font-medium mt-1 flex items-center justify-center gap-1">
                  <Ban className="w-3 h-3" />
                  Not Available
                </div>
              )}
            </div>
            <div className="text-center p-3 bg-white rounded-lg border">
              <div
                className={`text-2xl font-bold ${getBalanceColor(
                  leaveBalance.personalLeave,
                  leaveBalance.personalLeaveLimit || 6
                )}`}
              >
                {leaveBalance.personalLeave}
              </div>
              <div className="text-sm text-muted-foreground">
                Personal Leave
              </div>
              <div className="text-xs text-gray-500">
                / {leaveBalance.personalLeaveLimit || 6} days
              </div>
              {leaveBalance.personalLeave === 0 && (
                <div className="text-xs text-red-500 font-medium mt-1 flex items-center justify-center gap-1">
                  <Ban className="w-3 h-3" />
                  Not Available
                </div>
              )}
            </div>
          </div>
        </Card>
      )}

      {/* Leave Requests List */}
      <div>
        <h3 className="text-lg font-semibold mb-4">My Leave Requests</h3>
        {leaveRequests.length === 0 ? (
          <Card className="p-8 text-center">
            <CalendarDays className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No leave requests</h3>
            <p className="text-muted-foreground mb-4">
              You haven't applied for any leave yet
            </p>
            <Button onClick={() => setShowForm(true)}>
              Apply for Your First Leave
            </Button>
          </Card>
        ) : (
          <div className="space-y-4">
            {leaveRequests.map((request) => {
              const LeaveTypeIcon = getLeaveTypeIcon(request.type);
              const remainingDays = getRemainingDays(request.type);
              const leaveLimit = getLeaveLimit(request.type);

              return (
                <Card key={request._id || request.id} className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <LeaveTypeIcon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold">{request.type}</h3>
                          {getStatusBadge(request.status)}
                          <Badge
                            variant="outline"
                            className={`${
                              remainingDays === 0
                                ? "bg-red-50 text-red-700 border-red-200"
                                : "bg-blue-50 text-blue-700"
                            }`}
                          >
                            {remainingDays === 0 ? (
                              <span className="flex items-center gap-1">
                                <Ban className="w-3 h-3" />
                                No Balance
                              </span>
                            ) : (
                              `Balance: ${remainingDays}/${leaveLimit} days`
                            )}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            <span>
                              {new Date(request.startDate).toLocaleDateString()}{" "}
                              - {new Date(request.endDate).toLocaleDateString()}
                            </span>
                          </div>
                          <div>
                            <span className="font-medium">
                              {request.days || 1}
                            </span>{" "}
                            day
                            {request.days !== 1 ? "s" : ""}
                          </div>
                          <div className="truncate" title={request.reason}>
                            {request.reason}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Applied:{" "}
                            {new Date(request.appliedDate).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                    </div>
                    {request.status === "pending" && (
                      <div className="flex gap-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() =>
                            handleCancel(request._id || request.id)
                          }
                        >
                          Cancel
                        </Button>
                      </div>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Leave Application Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-2xl">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">
                  Apply for Leave
                  {currentEmployeeId && (
                    <span className="text-sm font-normal text-muted-foreground ml-2">
                      (Employee ID: {currentEmployeeId})
                    </span>
                  )}
                </h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowForm(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <form onSubmit={handleFormSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Leave Type</Label>
                    <Select
                      value={formData.type}
                      onValueChange={handleLeaveTypeChange}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select leave type" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableLeaveTypes.map((leaveType) => (
                          <SelectItem
                            key={leaveType.value}
                            value={leaveType.value}
                            disabled={!leaveType.available}
                            className={
                              !leaveType.available
                                ? "opacity-50 cursor-not-allowed"
                                : ""
                            }
                          >
                            <div className="flex justify-between items-center w-full">
                              <span>{leaveType.label}</span>
                              {!leaveType.available && (
                                <Badge
                                  variant="destructive"
                                  className="ml-2 text-xs"
                                >
                                  Not Available
                                </Badge>
                              )}
                              {leaveType.available && (
                                <span className="text-xs text-green-600 ml-2">
                                  {leaveType.remainingDays} days left
                                </span>
                              )}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {!isLeaveTypeAvailable(formData.type) && (
                      <div className="text-sm text-red-600 bg-red-50 p-2 rounded flex items-center gap-2">
                        <Ban className="w-4 h-4" />
                        <span>
                          <strong>{formData.type}</strong> is not available. You
                          have 0 days remaining.
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="days">Duration</Label>
                    <div className="text-sm text-muted-foreground p-2 bg-muted rounded">
                      {formData.startDate && formData.endDate
                        ? `${requestedDays} days`
                        : "Select dates to calculate duration"}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Start Date</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={formData.startDate}
                      onChange={(e) =>
                        setFormData({ ...formData, startDate: e.target.value })
                      }
                      required
                      disabled={!isLeaveTypeAvailable(formData.type)}
                      min={new Date().toISOString().split("T")[0]}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endDate">End Date</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={formData.endDate}
                      onChange={(e) =>
                        setFormData({ ...formData, endDate: e.target.value })
                      }
                      required
                      disabled={!isLeaveTypeAvailable(formData.type)}
                      min={
                        formData.startDate ||
                        new Date().toISOString().split("T")[0]
                      }
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reason">Reason</Label>
                  <Textarea
                    id="reason"
                    placeholder="Please provide a reason for your leave..."
                    value={formData.reason}
                    onChange={(e) =>
                      setFormData({ ...formData, reason: e.target.value })
                    }
                    required
                    rows={3}
                    disabled={!isLeaveTypeAvailable(formData.type)}
                  />
                  <p className="text-xs text-muted-foreground">
                    {formData.reason.length}/10 characters minimum
                  </p>
                </div>

                {/* Leave Balance Preview */}
                {currentEmployeeId && (
                  <div
                    className={`p-3 rounded-lg ${
                      isLeaveTypeAvailable(formData.type)
                        ? "bg-blue-50 border border-blue-200"
                        : "bg-red-50 border border-red-200"
                    }`}
                  >
                    <div className="flex items-center gap-2 text-sm">
                      {isLeaveTypeAvailable(formData.type) ? (
                        <>
                          <TrendingDown className="w-4 h-4 text-blue-600" />
                          <span className="font-medium text-blue-800">
                            Current {formData.type} Balance:{" "}
                            {getRemainingDays(formData.type)}/
                            {getLeaveLimit(formData.type)} days
                          </span>
                        </>
                      ) : (
                        <>
                          <Ban className="w-4 h-4 text-red-600" />
                          <span className="font-medium text-red-800">
                            {formData.type} Not Available - 0 days remaining
                          </span>
                        </>
                      )}
                    </div>
                    {formData.startDate &&
                      formData.endDate &&
                      isLeaveTypeAvailable(formData.type) && (
                        <div className="mt-2 text-sm text-blue-700">
                          Requested: {requestedDays} days | Remaining after
                          approval:{" "}
                          {getRemainingDays(formData.type) - requestedDays} days
                        </div>
                      )}
                  </div>
                )}

                <div className="flex gap-2 justify-end pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowForm(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={
                      submitting || !isLeaveTypeAvailable(formData.type)
                    }
                  >
                    {submitting
                      ? "Submitting..."
                      : !isLeaveTypeAvailable(formData.type)
                      ? "Leave Not Available"
                      : "Submit Leave Request"}
                  </Button>
                </div>
              </form>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default LeaveTab;
